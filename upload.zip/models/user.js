const pool = require('../config/pool.js');

const User = {
    
};

module.exports = User;
